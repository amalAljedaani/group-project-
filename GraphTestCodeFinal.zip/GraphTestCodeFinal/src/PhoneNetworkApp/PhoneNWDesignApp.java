/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PhoneNetworkApp;

import GraphFramework.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PhoneNWDesignApp extends BluePRGraph {

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("fileQ1.txt");
        File file1 = new File("f2.txt");
        Scanner input = new Scanner(System.in);
        String complete = "";
        String choice;
// 1> read from file
// 2 > req 2 , which case? n=? 
//        do {
//            choice = input.next();
//            switch (choice) {
//                case "1":
//                    BluePRGraph g = new BluePRGraph();
//                    g.read_from_file(file);
//                    MSTAlgorithm kruskalAlgorithm = new KruskalAlg(g);
//
//                    // Print the edges in Kruskal's minimum spanning tree     
//                    kruskalAlgorithm.displayResultingMST();
//
//                    // Run Prim's algorithm to get the minimum spanning tree
//                    MSTAlgorithm primAlgorithm = new MHPrimAlg(g);
//
//                    // Print the edges in Prim's minimum spanning tree
//                    primAlgorithm.displayResultingMST();
//
//                    break;
//                case "2":
//                     BluePRGraph g2 = new BluePRGraph();
//                     String case2ch=input.next();
//                     
//                    break;
//            }
//            complete = input.next();
//        } while (complete.equalsIgnoreCase("yes"));

        BluePRGraph g = new BluePRGraph();
        g.read_from_file(file);

        MSTAlgorithm kruskalAlgorithm = new KruskalAlg(g);

        // Print the edges in Kruskal's minimum spanning tree     
        kruskalAlgorithm.displayResultingMST();

        // Run Prim's algorithm to get the minimum spanning tree
        MSTAlgorithm primAlgorithm = new MHPrimAlg(g);

        // Print the edges in Prim's minimum spanning tree
        primAlgorithm.displayResultingMST();
   
       

        //------------------------------------------------------------------------------------
        BluePRGraph g2 = new BluePRGraph();

        System.out.println("\n\n");
        g2.makeGraph(10000, 25000);
        

        //MSTAlgorithm kruskal = new KruskalAlg(g2);
        // Print the edges in Kruskal's minimum spanning tree    
        
        //MSTAlgorithm prim = new MHPrimAlg(g2);
        
            
        
        
        /*int i=0;
        while(i!=10) {*/
            long start = System.currentTimeMillis();
            //
            MSTAlgorithm kruskal = new KruskalAlg(g2);
            kruskal.kruskal();
            kruskal.displayCost();
            long end = System.currentTimeMillis();
            long executeTime = end - start;
            System.out.println("===============Kruk==========================");
            System.out.println("executuon time is: " + executeTime);
            System.out.println("=========================================");
            
            long starti = System.currentTimeMillis();
            //
            MSTAlgorithm prim = new MHPrimAlg(g2);
            prim.primeMH_FindMST();
            prim.displayCost();
            long endi = System.currentTimeMillis();
            long executeTimee = endi - starti;
            System.out.println("===============prim==========================");
            System.out.println("executuon time is: " + executeTimee);
            System.out.println("=========================================");
            
            System.out.println("-----------------------------------------------------------------------------------------------------");
            //i++;
       //}
        

        
        
        // Run Prim's algorithm to get the minimum spanning tree
        

        // Print the edges in Prim's minimum spanning tree
        
        
//        /////////////////////////////////////////////// use this to compute time 
//         long start = System.currentTimeMillis();
//        
//
//        long end = System.currentTimeMillis();
//        long executeTime = end - start;
//        System.out.println("=========================================");
//        System.out.println("executuon time is: " + executeTime);
//        System.out.println("=========================================");
    }

}
